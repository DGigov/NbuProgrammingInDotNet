﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Rental.DbContexts;
using Rental.Models.BooksModels;

namespace Rental.Controllers
{
    // --------------------------------------------------------------------------------
    /// <summary>
    /// BooksController extends Controller - MVC controller for Rental Books handling.
    /// </summary>
    // --------------------------------------------------------------------------------
    public class BooksController : Controller
    {
        private BooksDb db = new BooksDb();

        // ********************************************************************************
        /// <summary>
        /// GET: Authors
        /// Index - index for the authors main view.
        /// </summary>
        /// <returns>ActionResult</returns>
        // ********************************************************************************
        public ActionResult Index()
        {
            var books = db.Books.Include(b => b.Author);
            return View(books.ToList());
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Books/Details/5
        /// Details - Called on details request for a certain book with id - id
        /// </summary>
        /// <param name="id">int?</param>
        /// <returns>ActionResult</returns>
        // ********************************************************************************
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Book book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Books/Create
        /// </summary>
        /// Create - Callback method on book create request by the user
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public ActionResult Create()
        {
            ViewBag.AuthorId = new SelectList(db.Authors, "Id", "Name");
            return View();
        }

        // ********************************************************************************
        /// <summary>
        /// POST: Books/Create
        /// Create - Method creating the actual book and adding it to the database
        /// </summary>
        /// <param name="book"></param>
        /// Binding parameter for the values sent to the database
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                db.Books.Add(book);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.AuthorId = new SelectList(db.Authors, "Id", "Name", book.AuthorId);
            return View(book);
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Book/Edit/5
        /// </summary>
        /// Edit - callback method on book properties editing request
        /// <param name="id">int?</param>
        /// <returns>ActionResult(Book)</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Book book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            ViewBag.AuthorId = new SelectList(db.Authors, "Id", "Name", book.AuthorId);
            return View(book);
        }

        // ********************************************************************************
        /// <summary>
        /// POST: Books/Edit/5
        /// Edit - callback method on book properties editing result
        /// </summary>
        /// <param name="book"></param>
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Book book)
        {
            if (ModelState.IsValid)
            {
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AuthorId = new SelectList(db.Authors, "Id", "Name", book.AuthorId);
            return View(book);
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Authors/Delete/5
        /// Delete - callback method on book delete result
        /// </summary>
        /// <param id="int?"></param>
        /// Id of the book targeted to delete
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Book book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        // ********************************************************************************
        /// <summary>
        /// POST: Authors/Delete/5
        /// DeleteConfirmed - callback method on book delete confirmation
        /// </summary>
        /// <param int="id"></param>
        /// Id of the book to delete from the database
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Book book = db.Books.Find(id);
            db.Books.Remove(book);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}
