﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Rental.DbContexts;
using Rental.Models.BooksModels;

namespace Rental.Controllers
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    // --------------------------------------------------------------------------------
    /// <summary>
    /// AuthorsController extends Controller - MVC controller for the Authors handling.
    /// </summary>
    // --------------------------------------------------------------------------------
    public class AuthorsController : Controller
    {
        private BooksDb db = new BooksDb();

        // ********************************************************************************
        /// <summary>
        /// GET: Authors
        /// Index - index for the authors main view.
        /// </summary>
        /// <returns>ActionResult</returns>
        // ********************************************************************************
        public ActionResult Index()
        {
            return View(db.Authors.ToList());
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Authors/Details/5
        /// Details - Called on details request for a certain author with id - id
        /// </summary>
        /// <param name="id">int?</param>
        /// <returns>ActionResult</returns>
        // ********************************************************************************
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Author author = db.Authors.Find(id);
            if (author == null)
            {
                return HttpNotFound();
            }
            return View(author);
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Authors/Create
        /// </summary>
        /// Create - Callback method on authors create request by the user
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public ActionResult Create()
        {
            return View();
        }

        // ********************************************************************************
        /// <summary>
        /// POST: Authors/Create
        /// Create - Method creating the actual author and adding him to the database
        /// </summary>
        /// <param author="Author"></param>
        /// Binding parameter for the values sent to the database
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] Author author)
        {
            if (ModelState.IsValid)
            {
                db.Authors.Add(author);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(author);
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Authors/Edit/5
        /// </summary>
        /// Edit - callback method on author properties editing request
        /// <param name="id">int?</param>
        /// <returns>ActionResult(Author)</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Author author = db.Authors.Find(id);
            if (author == null)
            {
                return HttpNotFound();
            }
            return View(author);
        }

        // ********************************************************************************
        /// <summary>
        /// POST: Authors/Edit/5
        /// Edit - callback method on author properties editing result
        /// </summary>
        /// <param author="Author"></param>
        /// Binding parameter for the values sent to the database.
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] Author author)
        {
            if (ModelState.IsValid)
            {
                db.Entry(author).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(author);
        }

        // ********************************************************************************
        /// <summary>
        /// GET: Authors/Delete/5
        /// Delete - callback method on author delete result
        /// </summary>
        /// <param id="int?"></param>
        /// Id of the author targeted to delete
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Author author = db.Authors.Find(id);
            if (author == null)
            {
                return HttpNotFound();
            }
            return View(author);
        }

        // ********************************************************************************
        /// <summary>
        /// POST: Authors/Delete/5
        /// DeleteConfirmed - callback method on author delete confirmation
        /// </summary>
        /// <param int="id"></param>
        /// Id of the author to delete from the database
        /// <returns>ActionResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Author author = db.Authors.Find(id);
            db.Authors.Remove(author);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}
