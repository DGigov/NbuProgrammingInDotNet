﻿using System;
using System.Globalization;
using System.Web.Mvc;

namespace Rental.Binders
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class DecimalModelBinder : IModelBinder
    {
        // ********************************************************************************
        /// <summary>
        /// Binder for decimal adjustment according to curent user culture.
        /// </summary>
        /// <param name="controllerContext">
        /// type ControllerContext
        /// Encapsulates information about an HTTP request that matches specified System.Web.Routing.RouteBase
        /// and System.Web.Mvc.ControllerBase instances.
        /// </param>
        /// <param name="bindingContext">
        /// type ModelBindingContext
        /// Provides the context in which a model binder functions.
        /// </param>
        /// <returns>object</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            ValueProviderResult valueResult = bindingContext.ValueProvider
                .GetValue(bindingContext.ModelName);
            ModelState modelState = new ModelState { Value = valueResult };
            object actualValue = null;
            try
            {
                string decValue = valueResult.AttemptedValue;
                decValue = decValue.Replace(".", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
                decValue = decValue.Replace(",", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);


                actualValue = Convert.ToDecimal(decValue,
                    CultureInfo.CurrentCulture);
            }
            catch (FormatException e)
            {
                modelState.Errors.Add(e);
            }

            bindingContext.ModelState.Add(bindingContext.ModelName, modelState);

            return actualValue;
        }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}