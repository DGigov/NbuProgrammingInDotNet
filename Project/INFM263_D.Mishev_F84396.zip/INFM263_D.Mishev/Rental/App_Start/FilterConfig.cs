﻿using System.Web;
using System.Web.Mvc;

namespace Rental
{
    // --------------------------------------------------------------------------------
    /// <summary>
    /// public class FilterConfig
    /// Namespace holding "Filtera"(each time run actions) on each of the requests 
    /// handled by the application.
    /// </summary>
    // --------------------------------------------------------------------------------
    public class FilterConfig
    {
        // ********************************************************************************
        /// <summary>
        /// Method bootstraping handling for global filters: CustomeErrors, Authentication
        /// </summary>
        /// <param name="filters">
        /// type GlobalFilterCollection
        /// Represents a class that contains all the global filters.
        /// </param>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            //filters.Add(new AuthorizeAttribute());
            filters.Add(new RequireHttpsAttribute());
        }
    }
}
