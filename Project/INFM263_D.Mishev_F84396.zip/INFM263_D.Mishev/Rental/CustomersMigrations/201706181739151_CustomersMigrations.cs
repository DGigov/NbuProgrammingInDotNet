namespace Rental.CustomersMigrations
{
    using System;
    using System.Data.Entity.Migrations;
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public partial class CustomersMigrations : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}
