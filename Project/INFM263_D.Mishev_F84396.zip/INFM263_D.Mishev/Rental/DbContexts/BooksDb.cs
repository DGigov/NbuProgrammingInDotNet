﻿using Rental.Models.BooksModels;
using System.Data.Entity;

namespace Rental.DbContexts
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class BooksDb : DbContext
    {
        public BooksDb()
            : base("DefaultConnection")
        {

        }
        public byte Id { get; set; }

        public DbSet<Book> Books { get; set; }

        public DbSet<Author> Authors { get; set; }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}