﻿using Microsoft.AspNet.Identity.EntityFramework;
using Rental.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Rental.DbContexts
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class IdentityDb : IdentityDbContext<ApplicationUser>
    {
        public IdentityDb()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public byte Id { get; set; }

        public static IdentityDb Create()
        {
            return new IdentityDb();
        }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}