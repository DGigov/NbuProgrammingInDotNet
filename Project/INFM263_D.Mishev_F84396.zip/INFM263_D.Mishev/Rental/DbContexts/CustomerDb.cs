﻿using System.Data.Entity;

namespace Rental.DbContexts
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class CustomerDb : DbContext
    {
        public CustomerDb()
            : base("DefaultConnection")
        {

        }

        public byte Id { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public string ConfirmPassword { get; set; }

        public string Ocupation { get; set; }

        public string Phone { get; set; }

        public System.DateTime? Birthdate { get; set; }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}