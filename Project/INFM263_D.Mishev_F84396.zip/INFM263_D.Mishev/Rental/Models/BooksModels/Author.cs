﻿using System.ComponentModel.DataAnnotations;

namespace Rental.Models.BooksModels
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    // --------------------------------------------------------------------------------
    /// <summary>
    /// Author - POCO
    /// </summary>
    // --------------------------------------------------------------------------------
    public class Author
    {
        public int Id { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Field {0} is required")]
        public string Name { get; set; }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}