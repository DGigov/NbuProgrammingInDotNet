﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Rental.Models.BooksModels
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    // --------------------------------------------------------------------------------
    /// <summary>
    /// Book - POCO
    /// </summary>
    // --------------------------------------------------------------------------------
    public class Book
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Field {0} is required")]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Required]
        [Display(Name = "Author")]
        public int AuthorId { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [Display(Name = "Price")]
        public decimal Price { get; set; }

        [ForeignKey(nameof(AuthorId))]
        public virtual Author Author { get; set; }

    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}