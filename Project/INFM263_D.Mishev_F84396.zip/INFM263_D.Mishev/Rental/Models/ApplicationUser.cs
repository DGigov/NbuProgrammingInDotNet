﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;

namespace Rental.Models
{
    // --------------------------------------------------------------------------------
    /// <summary>
    /// Application user model (extends Identity User - Default EntityFramework IUser implementation).
    /// </summary>
    // --------------------------------------------------------------------------------
    public class ApplicationUser : IdentityUser
    {
        /// <summary>
        /// Ocupation getter/setter of the Application User
        /// </summary>
        public string Ocupation { get; set; }

        /// <summary>
        /// Phone getter/setter of the Application User
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// Birthdate getter/setter of the Application User
        /// </summary>
        public System.DateTime? Birthdate { get; set; }

        // ********************************************************************************
        /// <summary>
        /// GenerateUserIdentityAsync - async method for handling user claims
        /// </summary>
        /// <returns>Task{ClaimsIdentity}</returns>
        /// <created>Deian,6/19/2017</created>
        /// <changed>Deian,6/19/2017</changed>
        // ********************************************************************************
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }

    
}