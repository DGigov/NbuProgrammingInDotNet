﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Rental.Models
{
    /// <summary>
    /// VerifyAge - CLass handling age varification
    /// </summary>
    public class VerifyAge : ValidationAttribute
    {
        // ********************************************************************************
        /// <summary>
        /// IsValid - Method handlign age varification for new app customers
        /// [VerifyAge] annotation
        /// </summary>
        /// <param name="value"></param>
        /// type object
        /// <param name="validationContext"></param>
        /// type ValidationContext
        /// Describes the context in which a validation check is performed.
        /// <returns>ValidationResult</returns>
        /// <created>Deian,6/18/2017</created>
        /// <changed>Deian,6/18/2017</changed>
        // ********************************************************************************
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var customer = (RegisterViewModel)validationContext.ObjectInstance;

            if (customer.Birthdate == null)
                return new ValidationResult("Birthdate is required.");

            var age = DateTime.Today.Year - customer.Birthdate.Value.Year;

            return (age >= 18)
                ? ValidationResult.Success
                : new ValidationResult("Customer should be at least 18 years old to use the service.");
        }
    }
}