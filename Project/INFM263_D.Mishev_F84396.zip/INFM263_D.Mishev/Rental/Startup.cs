﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Rental.Startup))]
namespace Rental
{
    public partial class Startup
    {
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}
